
-- Rainbow Physics Guns and Players --
-- Copyright Snowie 2016 --
-- Contact via Steam: http://steamcommunity.com/id/SnowyButt/

-- Initialisation File --

thcRainbowsConfig = {}
include("rainbows/configuration.lua")
include("rainbows/main.lua")