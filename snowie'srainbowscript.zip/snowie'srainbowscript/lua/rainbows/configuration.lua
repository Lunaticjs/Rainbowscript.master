-- THC Rainbow Physics Guns and Players --
-- Copyright Snowie 2016 --
-- Contact via Steam: http://steamcommunity.com/id/SnowyButt/ --

-- Configuration --

thcRainbowsConfig.SteamIDs = {} -- List of Steam IDS that have the colour changing effect.
thcRainbowsConfig.SteamIDs["STEAM_0:1:95170556"] = true

thcRainbowsConfig.UserGroups = {} -- List of user groups that have the colour changing effect.
thcRainbowsConfig.UserGroups["nightmare"] = true
thcRainbowsConfig.UserGroups["superadmin"] = true
thcRainbowsConfig.UserGroups["vip"] = true
thcRainbowsConfig.UserGroups["owner"] = true
thcRainbowsConfig.UserGroups["special"] = true
thcRainbowsConfig.UserGroups["headadmin"] = true
thcRainbowsConfig.UserGroups["co-owner"] = true
thcRainbowsConfig.UserGroups["Owner"] = true
thcRainbowsConfig.UserGroups["Developer"] = true

thcRainbowsConfig.physicsGun = true -- True to make the physics gun change colour.
thcRainbowsConfig.playerColour = true -- True to make the player colour change colour.

thcRainbowsConfig.changeTime = 1 -- A higher number will change colour faster.

thcRainbowsConfig.everyoneHasRainbow = false -- True to make everyone on the server have the colour changing effect.